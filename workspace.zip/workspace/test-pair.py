import os
import argparse
import datetime
import pickle
import sys

import cv2 as cv
import numpy as np

import altusi.config as cfg
from altusi.facelibs import FaceAligner, FaceDetector, \
        FaceEmbedder, FaceLandmarker, faceutils
from altusi import Logger

LOG = Logger(__file__.split('.')[0])

detector = FaceDetector()
landmarker = FaceLandmarker()
aligner = FaceAligner()
embedder = FaceEmbedder()
LOG.info('Face Objects initialization done\n')


def app():
    known_names, known_embs, known_cus_ids = faceutils.loadFaceData(
            cfg.FACE_NAMES_PKL, cfg.FACE_EMBS_PKL, cfg.CUS_IDS_PKL)
    LOG.debug('Face Data loading done\n')

    THRESH = 0.45
    P = TP = 0
    N = TN = 0


    test_cnt = test_correct = 0
    LOG.debug('Test being performed...')
    for i, emb1 in enumerate(known_embs):
        name1 = known_names[i]
        for j, emb2 in enumerate(known_embs):
            if i == j: continue

            test_cnt += 1
            name2 = known_names[j]

            dist = faceutils.getDistance(emb1, emb2)
            result = dist < THRESH
            if name1 == name2:
                P += 1
                if result:
                    TP += 1
                    test_correct += 1

            if name1 != name2:
                N += 1
                if not result:
                    TN += 1
                    test_correct += 1

        if (i+1) % 50 == 0 or i+1 == len(known_embs):
            LOG.debug(f'\tImages processed: {i+1}/{len(known_embs)}')

    acc = 1. * test_correct / test_cnt
    TPR = 1. * TP / P
    TNR = 1. * TN / N
    LOG.info(f'TPR: {TPR:.6f}')
    LOG.info(f'TNR: {TNR:.6f}')
    LOG.info(f'Accuracy: {acc:.6f}')


def main():
    app()


if __name__ == '__main__':
    LOG.info('Raspberry Pi: Test Pairs\n')

    main()

    LOG.info('Process done')
