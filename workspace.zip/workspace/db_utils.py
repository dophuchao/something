import datetime
import os
import threading
import uuid
from pprint import pprint
from threading import Thread

import boto3
import cv2
import pymysql

PRODUCTION = {
    'user': 'bk',
    'password': 'wearelegends!!!',
    'host': 'rdf-prod-db-legenddb-01.cqewcthnj9ha.ap-southeast-1.rds.amazonaws.com',
    'port': 51894,
    'db': 'predatordb'
}

TESTING = {
    'user': 'rdfdbtest01',
    'password': 'rdfwin888',
    'host': 'rdf-test-db-01.cqewcthnj9ha.ap-southeast-1.rds.amazonaws.com',
    'port': 23299,
    'db': 'predatordb'
}

DEVELOPMENT = {
    'user': 'thomas',
    'password': '1234567890',
    'host': '192.168.0.11',
    'port': 3306,
    'db': 'predatordb'
}

STORE_ID = -1


class DatabaseUtils:
    def __init__(self, cfg):
        self.connection = pymysql.connect(host=cfg['host'],
                                          port=cfg['port'],
                                          user=cfg['user'],
                                          password=cfg['password'],
                                          db=cfg['db'],
                                          charset='utf8mb4',
                                          cursorclass=pymysql.cursors.DictCursor,
                                          autocommit=True)
        self.connection_lock = threading.Lock()
        self.s3_client = boto3.client('s3')
        self.s3_client_lock = threading.Lock()

    def execute_put(self, query, args):
        with self.connection_lock:
            self.connection.ping(reconnect=True)
            with self.connection.cursor() as cursor:
                cursor.execute(query, args)

    def execute_get(self, query, args):
        with self.connection_lock:
            self.connection.ping(reconnect=True)
            with self.connection.cursor() as cursor:
                cursor.execute(query, args)
                results = cursor.fetchall()
        return results

    def async_add_new_person(self, image, appearance_time, store_id):
        t = Thread(target=self.add_new_person,
                   args=(image, appearance_time, store_id,),
                   daemon=True)
        t.start()
        return t

    def async_add_history(self, appearance_time, customer_id, store_id, image):
        t = Thread(target=self.add_history_2,
                   args=(appearance_time, customer_id, store_id, image,),
                   daemon=True)
        t.start()

    def add_new_person(self, image, appearance_time, store_id):
        cus_code, face_id = self.add_customer()
        customer_id = self.get_customer_id(
            cus_code=cus_code,
            face_id=face_id)
        image_url = self.upload_image_to_s3(
            store_id=store_id,
            customer_id=customer_id,
            image=image,
            appearance_time=appearance_time)
        self.add_customer_store(
            image_url=image_url,
            customer_id=customer_id,
            store_id=store_id,
            appearance_time=appearance_time)
        customer_store_id = self.get_customer_store_id(
            customer_id=customer_id,
            store_id=store_id)
        self.add_history(
            appearance_time=appearance_time,
            customer_id=customer_id,
            store_id=store_id,
            image_url=image_url)
        history_id = self.get_history(customer_store_id=customer_store_id, image_url=image_url)
        return customer_id, history_id, image_url

    def add_customer(self):
        cus_code = str(uuid.uuid4())
        face_id = str(uuid.uuid4())
        #
        query = ('INSERT INTO `predatordb`.`bus_customer` '
                 '(`cus_code`,`face_id`) '
                 'VALUES (%s, %s)')
        args = (cus_code, face_id,)
        self.execute_put(query, args)
        return cus_code, face_id

    def get_customer_id(self, cus_code, face_id):
        query = ('SELECT `bus_customer`.`id` '
                 'FROM `predatordb`.`bus_customer` '
                 'WHERE `bus_customer`.`cus_code` = %s '
                 'AND `bus_customer`.`face_id` = %s')
        args = (cus_code, face_id,)
        results = self.execute_get(query, args)
        return results[0]['id']

    def add_customer_store(self, image_url, customer_id, store_id, gender=1, age=1,
                           appearance_time=datetime.datetime.now(),
                           is_customer=0, pos_customer_name=''):
        query = ('INSERT INTO `predatordb`.`customer_store` '
                 '(`image_url`,`bus_customer_id`,`bus_store_id`,`rdf_customer_gender`, '
                 '`rdf_age_range_id`,`first_entered_time`,`is_customer`,`pos_customer_name`) '
                 'VALUES (%s,%s,%s,%s,%s,%s,%s,%s)')
        args = (image_url, customer_id, store_id, gender,
                age, appearance_time, is_customer, pos_customer_name,)
        self.execute_put(query, args)

    def get_customer_store_id(self, customer_id, store_id):
        query = ('SELECT `customer_store`.`id` '
                 'FROM `predatordb`.`customer_store` '
                 'WHERE `customer_store`.`bus_customer_id` = %s '
                 'AND `customer_store`.`bus_store_id` = %s ')
        results = self.execute_get(query, (customer_id, store_id,))
        return results[0]['id']

    def add_history(self, appearance_time, customer_id, store_id, image_url):
        customer_store_id = self.get_customer_store_id(customer_id, store_id)
        query = ('INSERT INTO `predatordb`.`history` '
                 '(`recognized_time`,`customer_store_id`,`customer_img_url`) '
                 'VALUES (%s,%s,%s) ')
        self.execute_put(query, (appearance_time, customer_store_id, image_url,))

    def add_history_2(self, appearance_time, customer_id, store_id, image):
        customer_store_id = self.get_customer_store_id(customer_id, store_id)
        query = ('INSERT INTO `predatordb`.`history` '
                 '(`recognized_time`,`customer_store_id`,`customer_img_url`) '
                 'VALUES (%s,%s,%s) ')
        image_url = self.upload_image_to_s3(
            store_id=store_id,
            customer_id=customer_id,
            image=image,
            appearance_time=appearance_time)
        self.execute_put(query, (appearance_time, customer_store_id, image_url,))

    def get_history(self, customer_store_id, image_url):
        query = ('SELECT `history`.`id` '
                 'FROM `predatordb`.`history` '
                 'WHERE `history`.`customer_store_id` = %s '
                 'AND `history`.`customer_img_url` = %s ')
        results = self.execute_get(query, (customer_store_id, image_url,))
        return results[0]['id']

    def get_attendance_statistic(self,
                                 morning_end=3600 * 12.5,
                                 afternoon_start=3600 * 13.25,
                                 start_date='2019-11-04',
                                 end_date='2019-12-01',
                                 store_id=-1):
        query = ('SELECT cs.bus_customer_id, '
                 '       cs.pos_customer_name, '
                 '       DATE(h.recognized_time)                        AS stats_date, '
                 '       MIN(IF(TIME_TO_SEC(h.recognized_time) <= %s, '
                 '              TIME_TO_SEC(h.recognized_time), 86401)) AS t1, '
                 '       MAX(IF(TIME_TO_SEC(h.recognized_time) <= %s, '
                 '              TIME_TO_SEC(h.recognized_time), -1))    AS t2, '
                 '       MIN(IF(TIME_TO_SEC(h.recognized_time) >= %s, '
                 '              TIME_TO_SEC(h.recognized_time), 86401)) AS t3, '
                 '       MAX(IF(TIME_TO_SEC(h.recognized_time) >= %s, '
                 '              TIME_TO_SEC(h.recognized_time), -1))    AS t4 '
                 'FROM history h '
                 '         INNER JOIN customer_store cs on h.customer_store_id = cs.id '
                 'WHERE h.recognized_time >= %s '
                 '  AND h.recognized_time < %s '
                 '  AND cs.bus_store_id = %s '
                 'GROUP BY cs.bus_customer_id, cs.pos_customer_name, stats_date '
                 'ORDER BY cs.bus_customer_id, cs.pos_customer_name, stats_date; ')
        results = self.execute_get(query, (morning_end, morning_end,
                                           afternoon_start, afternoon_start,
                                           start_date, end_date, store_id,))
        return results

    def upload_image_to_s3(self, store_id, customer_id, image, appearance_time):
        # create folder that contains temporarily image if not exists
        temp_image_folder = 'temp_images'
        if not os.path.exists(temp_image_folder):
            os.makedirs(temp_image_folder)
        # generate image info for upload
        file_name = '{0}_{1}__{2}.jpg'.format(
            store_id, customer_id, time_str(appearance_time))
        file_path = os.path.join(temp_image_folder, file_name)
        file_url = os.path.join(
            temp_image_folder, str(store_id), date_str(appearance_time), file_name)
        # write image to disk
        cv2.imwrite(file_path, image)
        # read image as byte array
        with open(file_path, 'rb') as file:
            file_data = file.read()
        # remove temp file
        os.remove(file_path)
        # upload image
        with self.s3_client_lock:
            self.s3_client.put_object(
                Body=file_data,
                Bucket='goshawk-face-data',
                Key=file_url,
                ACL='public-read',
                ContentType='image/jpeg')
        # return image url
        return 'https://goshawk-face-data.s3-ap-southeast-1.amazonaws.com/{}'.format(file_url)

    def close(self):
        with self.connection_lock:
            self.connection.close()


def date_str(dt=datetime.datetime.now()):
    return dt.strftime('%Y_%m_%d')


def time_str(dt=datetime.datetime.now()):
    return dt.strftime('%Y_%m_%d___%H_%M_%S_%f')[:-3]


def date_range(start_date, end_date):
    d = start_date.date()
    end_date = end_date.date()
    while d < end_date:
        yield d
        d = d + datetime.timedelta(days=1)

def test_add_new_person():
    dbutils = DatabaseUtils(cfg=DEVELOPMENT)
    threads = []
    # add new
    for i in range(1000):
        threads.append(dbutils.async_add_new_person(cv2.imread('/home/tom/Pictures/1.jpg'),
                                                    datetime.datetime.now(), STORE_ID))
    for thread in threads:
        thread.join()


if __name__ == '__main__':
    test_attendance_statistic()
