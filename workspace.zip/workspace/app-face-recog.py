import os
import time
import datetime
from threading import Thread
from collections import Counter

import RPi.GPIO as GPIO
import cv2 as cv
import numpy as np

from altusi import helper, imgproc, Logger
from altusi import config as cfg, visualizer as vis
from altusi.facelibs import FaceAligner, FaceDetector, \
        FaceEmbedder, FaceLandmarker, faceutils
from altusi import IDTracker
from altusi.lcd import LCD

from altusi.telegrambot import TelegramBot
from db_utils import DatabaseUtils, PRODUCTION

last_times = {}

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
BUZZER = 23
GPIO.setup(BUZZER, GPIO.OUT)
teleBot = TelegramBot()

LOG = Logger(__file__.split('.')[0])

detector = FaceDetector()
landmarker = FaceLandmarker()
aligner = FaceAligner()
embedder = FaceEmbedder()
LOG.info('Face Objects initialization done')


def getFaceID(known_embs, known_names, emb, k=1):
    min_dist, min_idx = float('inf'), -1

    # perform kNN alogrithm
    dists = [faceutils.getDistance(emb, kemb) for kemb in known_embs]
    dists, names = zip(*sorted(zip(dists, known_names)))
    LOG.info('min dist: {:.3f}'.format(dists[0]))

    cnt = Counter()
    for i in range(len(dists)):
        if dists[i] > 0.45: break
        cnt[names[i]] += 1

    common_cnt = 0
    if len(cnt):
        common_name, common_cnt = cnt.most_common(1)[0]
        LOG.debug('name: {} - cnt: {}'.format(common_name, common_cnt))

    return (True, common_name) if common_cnt >= k else (False, None)


def processResult(dbutils, avatar, recog_name, buzzer_pin, curr_t, 
        known_cus_ids, store_id):
    saved_path = os.path.join(cfg.SAVED_PHOTOS, recog_name + '.jpg')
    cv.imwrite(saved_path, avatar)

    helper.beep(buzzer_pin, duration=0.125)

    teleBot.sendText('{} checked in'.format(recog_name))
    teleBot.sendImg(saved_path)

    # add to database
    #dbutils.async_add_history(
    #    appearance_time=datetime.datetime.fromtimestamp(curr_t),
    #    customer_id=known_cus_ids[recog_name],
    #    store_id=store_id,
    #    image=avatar)
    LOG.info('processResult: done')


def app(video_path, video_name, store_id, show=False):
    # module help program insert face data to database
    dbutils = DatabaseUtils(PRODUCTION)

    # load pre-computed Face data
    known_names, known_embs, known_cus_ids = faceutils.loadFaceData(
        cfg.FACE_NAMES_PKL, cfg.FACE_EMBS_PKL, cfg.CUS_IDS_PKL)

    # LCD
    lcd = LCD('XtimuX', fullscreen=True)

    # initial tracker
    tracker = IDTracker()

    # initialize Video Capture
    cap = cv.VideoCapture(video_path)
    (W, H), FPS = imgproc.cameraCalibrate(cap)
    FRM_MOD = int(1. * FPS / cfg.pFPS + 0.5)
    LOG.info('Camera Info: ({}, {}) - {:.3f}'.format(W, H, FPS))

    helper.beep(BUZZER, duration=0.125)
    cnt_frm = 0
    while cap.isOpened():
        _, frm = cap.read()
        if not _:
            LOG.info('Reached the end of Video source')
            break

        cnt_frm += 1
        if cnt_frm % FRM_MOD == 0: continue
        vis_frm = frm.copy()
        vis_frm = vis.plotInfo(frm, 'XtimuX: Attendance System')

        _start_t = time.time()

        # detect faces and filter largest face
        scores, bboxes = detector.getFaces(frm, def_score=0.8)
        bbox = faceutils.getLargestBBox(bboxes)
        if not bbox: 
            _ = tracker.update(False, None)
            vis_frm = cv.cvtColor(np.asarray(vis_frm), cv.COLOR_BGR2RGB)
            lcd.draw(vis_frm)
            continue


        # compute face embeddings
        face_image = frm[bbox[1]:bbox[3], bbox[0]:bbox[2]]
        landmark = landmarker.getLandmark(face_image)
        aligned_face = aligner.align(face_image, landmark)
        emb = embedder.getEmb(face_image)

        # predict identity
        flag, pred_name = getFaceID(known_embs, known_names, emb)

        # perform tracking
        recog_name = tracker.update(flag, pred_name)
        if not recog_name: 
            pass
        else:
            LOG.info('RECOG {}'.format(recog_name))
            vis_frm = vis.plotBBoxes(vis_frm, [bbox], [recog_name])
            vis_frm = vis.plotInfo(vis_frm, f'{recog_name} is recognized!', pos='bot')

            # process result
            curr_t = time.time()
            if recog_name not in last_times or curr_t - last_times[recog_name] > 5:
                try:
                    last_times[recog_name] = curr_t
                    avatar = imgproc.getPadding(frm, bbox, margin=0.8)
                    Thread(target=processResult,
                            args=(dbutils, avatar, recog_name, BUZZER, curr_t, 
                                known_cus_ids, store_id)).start()
                except Exception as e:
                    LOG.info(str(e))

            _prx_t = time.time() - _start_t

        vis_frm = cv.cvtColor(np.asarray(vis_frm), cv.COLOR_BGR2RGB)
        lcd.draw(vis_frm)

    cap.release()
    cv.destroyAllWindows()


def main(args):
    video_path = args.video if args.video else 0
    app(video_path, args.name, store_id=args.store_id)


if __name__ == '__main__':
    LOG.info('Raspberry Pi: Face Recognition\n')

    args = helper.getArgs()
    main(args)

    LOG.info('Process done')
