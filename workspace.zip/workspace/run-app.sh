#!/bin/bash

source /home/pi/openvino/bin/setupvars.sh
export DISPLAY=:0
/usr/bin/python3 app-face-recog.py -st 27
