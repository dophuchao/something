# AltusI
My library for Computer Vision and Artificial Intelligence

# Update
**2019, Oct 16:**
  - Add `facealigner` class
  - Add `facelandmarker` class
  - Add `facedetector` class

**2019, Sep 25:**
  - Add `config` for project's configuration
  - Add `helper` for support functions
  - Add `visualizer` module for visualization purpose
    - Develop `plotBBoxes` (with `classes`) functions to plot bboxes and classes with different colors

**2019, Sep 24:**
  - Add `logger` for logging purpose
