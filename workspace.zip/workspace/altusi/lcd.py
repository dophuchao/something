import cv2 as cv


class LCD:
    def __init__(self, win_name, fullscreen=True):
        if fullscreen:
            cv.namedWindow(win_name, cv.WND_PROP_FULLSCREEN)
            cv.setWindowProperty(win_name, cv.WND_PROP_FULLSCREEN, \
                    cv.WINDOW_FULLSCREEN)

        self.__win_name = win_name
    
    def draw(self, img):
        cv.imshow(self.__win_name, img)
        cv.waitKey(1)

