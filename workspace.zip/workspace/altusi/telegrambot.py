# import requests
import telegram

BOT_TOKEN = '803503723:AAGfqkVrU6Bywohv4QR-vSGGwxinI_XsV5Y'
BOT_CHAT_IDS = ['492238485', '537602881']
MSG_URL = 'https://api.telegram.org/bot{}/sendMessage?chat_id={}&parse_mode=Markdown&text={}'

bot = telegram.Bot(token=BOT_TOKEN)

class TelegramBot:
    @staticmethod
    def sendText(msg):
        for chat_id in BOT_CHAT_IDS:
            bot.send_message(chat_id=chat_id, text=msg)


    @staticmethod
    def sendImg(img_path):
        for chat_id in BOT_CHAT_IDS:
            bot.send_photo(chat_id=chat_id, photo=open(img_path, 'rb'))

