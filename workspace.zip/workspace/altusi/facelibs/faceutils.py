import numpy as np
import pickle


def getDistance(u, v):
    uv = np.dot(u, v)
    uu = np.dot(u, u)
    vv = np.dot(v, v)
    norm = np.sqrt(uu * vv) + 1e-6

    return 1 - uv / norm


def getLargestBBox(bboxes):
    max_idx, max_area = -1, 0
    for i, bbox in enumerate(bboxes):
        x1, y1, x2, y2 = bbox
        w, h = x2 - x1, y2 - y1
        if h >= 90 and w * h > max_area:
            max_area = w * h
            max_idx = i
    
    return bboxes[max_idx] if max_idx != -1 else None


def loadFaceData(names_pkl, embs_pkl, cus_ids_pkl):
    pkl_name = open(names_pkl, 'rb')
    face_names = pickle.load(pkl_name)
    pkl_name.close()

    pkl_emb = open(embs_pkl, 'rb')
    face_embs = pickle.load(pkl_emb)
    pkl_emb.close()

    pkl_cus_id = open(cus_ids_pkl, 'rb')
    cus_ids = pickle.load(pkl_cus_id)
    pkl_cus_id.close()

    return face_names, face_embs, cus_ids

