import os


# =============================================================================
# PROJECT'S ORGANIZATION
# =============================================================================
PROJECT_BASE = '.'
FACE_DATA_PATH = os.path.join(PROJECT_BASE, 'face-data')
SAVED_PHOTOS = os.path.join(PROJECT_BASE, 'saved-photos')

SOUND_PATH = 'sounds'

#===============================================================================
# PROJECT'S PARAMETERS
#===============================================================================
FONT = os.path.join(PROJECT_BASE, 'altusi', 'Aller_Bd.ttf')

TIME_FM = '-%Y%m%d-%H%M%S'

pFPS = 4 
SOUND = os.path.join(SOUND_PATH, 'aaaah.wav')
SOUND = os.path.join(SOUND_PATH, 'hello-2.wav')
UNKNOWN = os.path.join(SOUND_PATH, 'who-are-you.wav')

#===============================================================================
# PROJECT'S MODELS
#===============================================================================
MODEL_DIR = 'openvino-models'

# face detection model
FACE_DET_XML = os.path.join(MODEL_DIR, 'face-detection-adas-0001-fp16.xml')
FACE_DET_BIN = os.path.join(MODEL_DIR, 'face-detection-adas-0001-fp16.bin')

# facial landmark model
FACE_LM_XML = os.path.join(MODEL_DIR, 'landmarks-regression-retail-0009-fp16.xml')
FACE_LM_BIN = os.path.join(MODEL_DIR, 'landmarks-regression-retail-0009-fp16.bin')

# face reidentification model
FACE_EMB_XML = os.path.join(MODEL_DIR, 'face-reidentification-retail-0095-fp16.xml')
FACE_EMB_BIN = os.path.join(MODEL_DIR, 'face-reidentification-retail-0095-fp16.bin')

#===============================================================================
# PROJECT'S SHORTCUTS 
#===============================================================================
FACE_EMBS_PKL = os.path.join(FACE_DATA_PATH, 'kt-emb-20200706.h5')
FACE_NAMES_PKL = os.path.join(FACE_DATA_PATH, 'kt-name-20200706.h5')
CUS_IDS_PKL = os.path.join(FACE_DATA_PATH, 'kt-cus-id-20200706.h5')

