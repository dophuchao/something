from altusi import Logger
LOG = Logger(__file__.split('.')[0])

T_RECOG = 5
T_DIS = 4

class IDTracker:
    def __init__(self):
        self.tracking_names = []
        self.cnt_recogs = []
        self.cnt_dis = []

    def clear(self, idx=-1):
        for i in range(len(self.tracking_names)):
            if i == idx: continue
            self.cnt_dis[i] += 1

        for i in range(len(self.cnt_dis)-1, -1, -1):
            if self.cnt_dis[i] == T_DIS:
                del self.cnt_dis[i]
                del self.cnt_recogs[i]
                del self.tracking_names[i]


    def update(self, flag, pred_name):
        if len(self.tracking_names):
            LOG.debug(self)
        recog_name = None
        if not flag:
            self.clear()
            return None

        if pred_name in self.tracking_names:
            idx = self.tracking_names.index(pred_name)
            self.cnt_dis[idx] = 0
            self.cnt_recogs[idx] += 1
            if self.cnt_recogs[idx] == T_RECOG:
                LOG.debug('recog: {} - {}'.format(pred_name, self.cnt_recogs[idx]))
                self.cnt_recogs[idx] = 1
                recog_name = pred_name 
        else:
            idx = len(self.tracking_names)
            self.tracking_names.append(pred_name)
            self.cnt_recogs.append(1)
            self.cnt_dis.append(0)

        self.clear(idx)

        return recog_name

    def __str__(self):
        result = []
        for i, name in enumerate(self.tracking_names):
            partial = '{}:{}:{}'.format(
                name, self.cnt_recogs[i], self.cnt_dis[i])
            result.append(partial)

        return '|'.join(result)
