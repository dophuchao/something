import os
import argparse
import datetime
import pickle
import sys

import cv2 as cv
import numpy as np

import altusi.config as cfg
from altusi.facelibs import FaceAligner, FaceDetector, FaceEmbedder, FaceLandmarker
from altusi import Logger
#from db_utils import DatabaseUtils, PRODUCTION

LOG = Logger('gen-embs')

detector = FaceDetector()
landmarker = FaceLandmarker()
aligner = FaceAligner()
embedder = FaceEmbedder()
LOG.info('Face Objects initialization done\n')


def getArgs():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', '-d', type=str,
            required=True,
            help='Path to Face Dataset')
    parser.add_argument('--storeid', '-st', type=str,
            required=True,
            help='Store ID to generate')
    args = parser.parse_args()
    return args


def getLargestBBox(bboxes):
    max_area, max_idx = 0, -1
    for i, bbox in enumerate(bboxes):
        x1, y1, x2, y2 = bbox
        w, h = x2 - x1, y2 - y1
        if max_area < w * h:
            max_idx = i
            max_area = w * h
    return bboxes[max_idx]


def processImage(image_path):
    image = cv.imread(image_path)
    scores, bboxes = detector.getFaces(image)
    assert len(bboxes)
    bbox = getLargestBBox(bboxes)
    face_image = image[bbox[1]:bbox[3], bbox[0]:bbox[2]]
    landmark = landmarker.getLandmark(face_image)
    aligned_face = aligner.align(face_image, landmark)
    emb = embedder.getEmb(aligned_face)

    return emb


def app(data_path):
    # module help program insert face data to database
    #dbutils = DatabaseUtils(PRODUCTION)
    #
    face_embs = []
    face_names = []

    if os.path.exists(cfg.CUS_IDS_PKL):
        LOG.debug('file exists nha')
        pkl_cus_id = open(cfg.CUS_IDS_PKL, 'rb')
        cus_id_dict = pickle.load(pkl_cus_id)
        pkl_cus_id.close()
    else:
        cus_id_dict = {}
    LOG.info('data path: {}'.format(data_path))

    for name in sorted(os.listdir(data_path)):
        LOG.info('folder in progress: {}'.format(name))
        name_path = os.path.join(data_path, name)
        for i, image_name in enumerate(os.listdir(name_path)):
            image_path = os.path.join(name_path, image_name)
            LOG.info(image_path)
            emb = processImage(image_path)
            face_embs.append(emb)
            face_names.append(name)
            # add new person to database
            if name not in cus_id_dict and i == 0:  # send once
                pass
#                customer_id = dbutils.add_new_person(
#                    image=cv.imread(image_path),
#                    appearance_time=datetime.datetime.now(),
#                    store_id=STORE_ID)[0]
#                cus_id_dict[name] = customer_id
#
        LOG.info('')

    face_embs = np.array(face_embs)
    LOG.info('face_embs shape: {}'.format(face_embs.shape))

    pkl_name = open(cfg.FACE_NAMES_PKL, 'wb')
    pickle.dump(face_names, pkl_name)
    pkl_name.close()

    pkl_emb = open(cfg.FACE_EMBS_PKL, 'wb')
    pickle.dump(face_embs, pkl_emb)
    pkl_emb.close()

    pkl_cus_id = open(cfg.CUS_IDS_PKL, 'wb')
    pickle.dump(cus_id_dict, pkl_cus_id)
    pkl_cus_id.close()


def main(args):
    STORE_ID = args.storeid
    app(args.dataset)


if __name__ == '__main__':
    LOG.info('Raspberry Pi: Generate Face Embeddings\n')

    args = getArgs()
    main(args)

    LOG.info('Process done')
